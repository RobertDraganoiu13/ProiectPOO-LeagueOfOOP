package map;

public enum TerrainType {
    Land, Volcanic, Desert, Woods
}
