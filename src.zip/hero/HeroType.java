package hero;

public enum HeroType {
    Knight, Pyromancer, Rogue, Wizard
}
