package hero;

public enum OverTimeEffects {
    None, Incapacitated, Damaged
}
